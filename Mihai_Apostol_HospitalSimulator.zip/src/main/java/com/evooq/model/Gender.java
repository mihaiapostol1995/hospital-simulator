package com.evooq.model;

public enum Gender {
    MALE, FEMALE, UNKNOWN
}
