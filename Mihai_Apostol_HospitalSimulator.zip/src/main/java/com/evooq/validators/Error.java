package com.evooq.validators;

public record Error(String message) {
}
